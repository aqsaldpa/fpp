package com.example.finalproject.fragment;

import android.content.Context;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;

import com.bumptech.glide.Glide;
import com.example.finalproject.Book;
import com.example.finalproject.BookData;
import com.example.finalproject.R;

import java.util.List;

public class BookAdapter  {
}
